import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  // Define any properties or methods for your dashboard here
  userData = {
    name: 'John Doe',
    email: 'johndoe@example.com',
    role: 'Admin'
  };
  

  // Example statistics or data you might display
  statistics = {
    totalUsers: 1200,
    activeUsers: 800,
    pendingRequests: 15
  };

  constructor() {}

  ngOnInit() {
    // Fetch data for dashboard from a service or API here
    // Example: this.dashboardService.getDashboardData().subscribe(data => { ... });
  }
}

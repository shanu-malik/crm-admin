export const LANGUAGES = { en: 'English', fr: 'Français' };

export const APP_CONFIG = {};

export class CoreModule {}

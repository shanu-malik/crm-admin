import { NgModule,CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routes';
import { AuthModule } from './features/auth/auth.module';
import { HeaderComponent } from './layout/header/header.component';
import { LayoutModule } from './layout/layout.module'

@NgModule({
  declarations: [AppComponent,HeaderComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AuthModule,
    LayoutModule,
    HeaderComponent
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LayoutComponent } from './layout.component';
import { HeaderComponent } from './header/header.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  declarations: [     // Declare LayoutComponent
    HeaderComponent,      // Declare HeaderComponent
    SidebarComponent      // Declare SidebarComponent
  ],
  imports: [
    CommonModule         // Import CommonModule for basic Angular directives
  ],
  exports: [  // Export LayoutComponent so it can be used in other modules
    HeaderComponent,      // Export HeaderComponent
    SidebarComponent      // Export SidebarComponent
  ]
})
export class LayoutModule { }

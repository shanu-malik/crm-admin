import { Component } from '@angular/core';

@Component({
  selector: 'app-layout',  // This should match the tag used in app.component.html
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss']
})
export class LayoutComponent {
  // Your component logic here
}

export class FooterComponent {}
